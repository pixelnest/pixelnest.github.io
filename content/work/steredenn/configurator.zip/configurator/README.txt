# Gamepad/Controller Configurator

Hello!

In order to improve the support for esoteric or rare controllers in Steredenn, we need *your* help.

Execute the "Configurator" executable (of your platform) and follow the instructions. Be careful: a small movement of a stick can be recorded on the wrong input. If you need to restart, just press "R" on your keyboard.

If a key is nonexistent on your controller, skip it with "Escape" on your keyboard. 

Then, send us the result (a .txt with the name of your controller is generated near the executable) to steredenn@pixelnest.io - thanks!